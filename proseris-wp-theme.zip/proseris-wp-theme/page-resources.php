<?php
/* Template Name: Resources (Converted) */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
get_template_part('template-parts/pages/resources');
get_footer();

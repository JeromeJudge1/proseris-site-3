<?php
/* Template Name: How It Works (Converted) */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
get_template_part('template-parts/pages/how-it-works');
get_footer();

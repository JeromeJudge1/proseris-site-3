<?php
/* Template Name: News (Converted) */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
get_template_part('template-parts/pages/news');
get_footer();

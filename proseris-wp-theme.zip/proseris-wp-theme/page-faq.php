<?php
/* Template Name: Faq (Converted) */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
get_template_part('template-parts/pages/faq');
get_footer();

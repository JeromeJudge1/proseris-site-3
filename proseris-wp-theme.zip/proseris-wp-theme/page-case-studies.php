<?php
/* Template Name: Case Studies (Converted) */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
get_template_part('template-parts/pages/case-studies');
get_footer();

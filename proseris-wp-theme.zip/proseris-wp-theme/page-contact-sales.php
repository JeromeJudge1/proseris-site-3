<?php
/* Template Name: Contact Sales (Converted) */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
get_template_part('template-parts/pages/contact-sales');
get_footer();

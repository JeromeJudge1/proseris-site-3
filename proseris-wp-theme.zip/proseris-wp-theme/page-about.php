<?php
/* Template Name: About (Converted) */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
get_template_part('template-parts/pages/about');
get_footer();

<?php
/* Template Name: Webinars (Converted) */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
get_template_part('template-parts/pages/webinars');
get_footer();
